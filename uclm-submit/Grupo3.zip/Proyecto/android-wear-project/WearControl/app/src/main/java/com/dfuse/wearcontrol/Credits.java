package com.dfuse.wearcontrol;

import android.app.Activity;
import android.os.Bundle;

public class Credits extends Activity {

   @Override
    protected void onCreate(Bundle dfuse) {
        super.onCreate(dfuse);
        setContentView(R.layout.credits);
    }
}
