/*
    Project: wearControl
    Author: Josue Gutierrez Duran
    WebPage:
    Class: Params
 */

package com.dfuse.wearcontrol;

public class Params {

    public static UDPLink UDP;

    public static final int socketListener = 11001;

    public static final int socketSender = 11000;

    public static String PIN = "1234";

    public static String ip;

}

